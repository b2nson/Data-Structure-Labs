#include "city.h"
using namespace std;

unsigned int City::getPopulation() const {
    return population;
}

std::string City::getName() const {
    return name;
}