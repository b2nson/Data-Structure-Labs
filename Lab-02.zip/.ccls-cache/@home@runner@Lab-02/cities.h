#include <vector>
#include "city.h"

class Cities {
private:
std::vector<City> cityList;

public:
void readCities();
void printCityList();
};